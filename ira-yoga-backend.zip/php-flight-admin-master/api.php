<?php
include_once('function.php');
$action=mysqli_real_escape_string($con,$_REQUEST['action']);
switch ($action) {
	case 'getLanguages':
		$result=getLanguages();
		$response['success']="success";
		$response['result']=$result;
		echo json_encode($response);
		exit;	
	break;
	case 'getLabel':
		$lang=mysqli_real_escape_string($con,$_REQUEST['language']);
		if(empty($lang)){
			$response['error']="Please provide language";
			echo json_encode($response);
			exit;
		}
		$result=getLabel($lang);
		$response['success']="success";
		$response['result']=$result;
		echo json_encode($response);
		exit;
	break;
	case 'register':
		$username=mysqli_real_escape_string($con,$_REQUEST['username']);
		$firstname=mysqli_real_escape_string($con,$_REQUEST['firstname']);
		$lastname=mysqli_real_escape_string($con,$_REQUEST['lastname']);
		$email=mysqli_real_escape_string($con,$_REQUEST['email']);
		$password=mysqli_real_escape_string($con,$_REQUEST['password']);
		$jobprofile=mysqli_real_escape_string($con,$_REQUEST['job_profile']);
		$result=register($username,$firstname,$lastname,$email,$password,$jobprofile);
		if ($result['flag']) {
			$response['success']=1;
			$response['msg']=$result['msg'];
		}
		else {
			$response['success']=0;
			$response['msg']=$result['msg'];			
		}
		echo json_encode($response);
	break;
	case 'activeAccount':
		$email=mysqli_real_escape_string($con,$_REQUEST['email']);
		echo activeAccount($email);
	break;
	case 'login':
		$username=mysqli_real_escape_string($con,$_REQUEST['username']);
		$connect_to=mysqli_real_escape_string($con,$_REQUEST['connect_to']);
		$password=mysqli_real_escape_string($con,$_REQUEST['password']);
		$app_id=mysqli_real_escape_string($con,$_REQUEST['app_id']);
		$firstname=mysqli_real_escape_string($con,$_REQUEST['firstname']);
		$lastname=mysqli_real_escape_string($con,$_REQUEST['lastname']);
		$result=login($username,$connect_to,$password,$app_id,$firstname,$lastname);
		if ($result['flag']) {
			$response['success']=1;
			$response['msg']=$result['msg'];
			$response['result']=$result['result'];
		}
		else {
			$response['success']=0;
			$response['msg']=$result['msg'];		
		}
		echo json_encode($response);
	break;
	case 'getPlaneTypes':
		$result=getPlaneTypes();
		$response['success']=1;
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'getManufacturereList':
		$plane_type_id=mysqli_real_escape_string($con,$_REQUEST['plane_type_id']);
		$engine_type=mysqli_real_escape_string($con,$_REQUEST['engine_type']);
		$result=getManufacturereList($plane_type_id,$engine_type);
		$response['success']=1;
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'getStateList':
		$result=getState();
		$response['success']=1;
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'getCityList':
		$state_id=mysqli_real_escape_string($con,$_REQUEST['state_id']);
		$result=getCityList($state_id);
		$response['success']=1;
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'getAirportList':
		$city_id=mysqli_real_escape_string($con,$_REQUEST['city_id']);
		$result=getAirportList($city_id);
		$response['success']=1;
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'getFacilityList':
		$result=getFacilityList();
		$response['success']=1;
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'getProfileDetails':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$result=getProfileDetails($user_id);
		$response['success']=1;
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'getUserPlanes':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$result=getUserPlanes($user_id);
		$response['success']=1;
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'addPlaneOfUser':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$model_id=mysqli_real_escape_string($con,$_REQUEST['model_id']);
		$result=addPlaneOfUser($user_id,$model_id);
		$response['success']=1;
		$response['msg']=$result;
		echo json_encode($response);
	break;
	case 'addAirportOfUser':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$airport_id=mysqli_real_escape_string($con,$_REQUEST['airport_id']);
		$result=addAirportOfUser($user_id,$airport_id);
		$response['success']=1;
		$response['msg']=$result;
		echo json_encode($response);
	break;
	case 'getUserAirports':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$result=getUserAirports($user_id);
		$response['success']=1;
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'changePassword':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$oldpassword=mysqli_real_escape_string($con,$_REQUEST['oldPass']);
		$newpassword=mysqli_real_escape_string($con,$_REQUEST['newPass']);
		$result=changePassword($user_id,$oldpassword,$newpassword);
		$response['success']=$result['flag'];
		$response['msg']=$result['msg'];
		echo json_encode($response);
	break;
	case 'updateUserNames':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$firstname=mysqli_real_escape_string($con,$_REQUEST['firstname']);
		$lastname=mysqli_real_escape_string($con,$_REQUEST['lastname']);
		$result=updateUserNames($user_id,$firstname,$lastname);
		$response['success']=$result['flag'];
		$response['msg']=$result['msg'];
		echo json_encode($response);
	break;
	case 'updateUserAbout':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$about=mysqli_real_escape_string($con,$_REQUEST['about']);
		$result=updateUserAbout($user_id,$about);
		$response['success']=$result['flag'];
		$response['msg']=$result['msg'];
		echo json_encode($response);
	break;
	case 'removeUserPlane':
		$up_id=mysqli_real_escape_string($con,$_REQUEST['up_id']);
		$result=removeUserPlane($up_id);
		$response['success']=$result['flag'];
		$response['msg']=$result['msg'];
		echo json_encode($response);
	break;
	case 'removeUserAirport':
		$ua_id=mysqli_real_escape_string($con,$_REQUEST['ua_id']);
		$result=removeUserAirport($ua_id);
		$response['success']=$result['flag'];
		$response['msg']=$result['msg'];
		echo json_encode($response);
	break;
	case 'updateCurrentPlane':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$up_id=mysqli_real_escape_string($con,$_REQUEST['up_id']);
		$result=updateCurrentPlane($user_id,$up_id);
		$response['success']=$result['flag'];
		$response['msg']=$result['msg'];
		echo json_encode($response);
	break;
	case 'updateCurrentAirport':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$ua_id=mysqli_real_escape_string($con,$_REQUEST['ua_id']);
		$result=updateCurrentAirport($user_id,$ua_id);
		$response['success']=$result['flag'];
		$response['msg']=$result['msg'];
		echo json_encode($response);
	break;
	case 'updateProfilePic':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$result=updateProfilePic($user_id);
		$response['success']=$result['flag'];
		$response['msg']=$result['msg'];
		echo json_encode($response);
	break;
	case 'getMechanicList':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$latitude=mysqli_real_escape_string($con,$_REQUEST['latitude']);
		$longitude=mysqli_real_escape_string($con,$_REQUEST['longitude']);
		$search=mysqli_real_escape_string($con,$_REQUEST['search']);
		$facilities=mysqli_real_escape_string($con,$_REQUEST['facilities']);
		$airport_id = mysqli_real_escape_string($con,$_REQUEST['airport_id']);
		$result=getMechanicList($airport_id,$user_id,$latitude,$longitude,$search,$facilities);
		$response['success'] = 1;
		$response['msg']="success";
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'addRating':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$rating=mysqli_real_escape_string($con,$_REQUEST['rating']);
		$mechanic_id=mysqli_real_escape_string($con,$_REQUEST['mechanic_id']);
		$comment=mysqli_real_escape_string($con,$_REQUEST['comment']);
		$result=addRating($user_id,$rating,$mechanic_id,$comment);
		$response['success']=$result['flag'];
		$response['msg']=$result['msg'];
		echo json_encode($response);
	break;
	case 'viewRating':
		$mechanic_id=mysqli_real_escape_string($con,$_REQUEST['mechanic_id']);
		$result=viewRating($mechanic_id);
		$response['success']=1;
		$response['result']=$result;
		$response['msg']="success";
		echo json_encode($response);
	break;
	case 'deleteRating':
		$review_id=mysqli_real_escape_string($con,$_REQUEST['review_id']);
		$result=deleteRating($review_id);
		$response['success']=$result['flag'];
		$response['msg']=$result['msg'];
		echo json_encode($response);
	break;
	case 'getModelList':
		$plane_type_id=mysqli_real_escape_string($con,$_REQUEST['plane_type_id']);
		$manufacturer_id=mysqli_real_escape_string($con,$_REQUEST['manufacturer_id']);
		$engine_type=mysqli_real_escape_string($con,$_REQUEST['engine_type']);
		$result=getModelList($plane_type_id,$manufacturer_id,$engine_type);
		$response['success']=1;
		$response['result']=$result;
		$response['msg']="success";
		echo json_encode($response);
	break;
	case 'forgetPassword':
		$email=mysqli_real_escape_string($con,$_REQUEST['email']);
		$result=forgetPassword($email);
		$response['success']=$result['flag'];
		$response['msg']=$result['msg'];
		echo json_encode($response);
	break;
	case 'confirmForgetPassword':
		$email=mysqli_real_escape_string($con,$_REQUEST['email']);
		$code=mysqli_real_escape_string($con,$_REQUEST['code']);
		echo confirmChangeForgetPassword($email,$code);
	break;
	case 'getAvgRating':
		$mechanic_id=mysqli_real_escape_string($con,$_REQUEST['mechanic_id']);
		$result=getAvgRating($mechanic_id);
		$response['success']=1;
		$response['msg']="success";
		$response['result']=$result;
		echo json_encode($response);
	break;	
	case 'getNearByAirports':
		$latitude=mysqli_real_escape_string($con,$_REQUEST['latitude']);
		$longitude=mysqli_real_escape_string($con,$_REQUEST['longitude']);
		$result=getNearByAirports($latitude,$longitude);
		$response['success']=1;
		$response['msg']="success";
		$response['result']=$result;
		echo json_encode($response);
	break;	
	case 'searchAirports':
		$keyword=mysqli_real_escape_string($con,$_REQUEST['keyword']);
		$result=searchAirports($keyword);
		$response['success']=1;
		$response['msg']="success";
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'getJobProfiles':
		$result=getJobProfiles();
		$response['success']=1;
		$response['msg']="success";
		$response['result']=$result;
		echo json_encode($response);
	break;
	case 'getCurrentPlane':
		$user_id=mysqli_real_escape_string($con,$_REQUEST['user_id']);
		$result=getCurrentPlane($user_id);
		$response['success']=1;
		$response['msg']="success";
		$response['result']=$result;
		echo json_encode($response);
	break;
	default:
		$response['error']="Invalid Action";
		echo json_encode($response);
	break;
}
?>