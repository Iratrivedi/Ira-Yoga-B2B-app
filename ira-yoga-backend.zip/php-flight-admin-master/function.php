<?php
include_once('db.php');
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
function throw_error($error){
	throw new Exception($error);
}
function generateRandomString($length=8){
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
function send_error($e,$modualName){
	$message=$modualName." || ".$e->getMessage()." || ".date('Y-m-d H:i:s') ."<br>"; 
	error_log($message,3,"log_error.html");
}
function getSendMail($email,$subject,$message){
	$moduleName="send_mail";
	try {

		$mail = new PHPMailer(true);
		// $mail->SMTPDebug = 2;      
		$mail->isSMTP(); 
     	$message.="<br><br>Thanks,<br>Betting";
     	$mail->isSMTP(); // tell to use smtp
 		$mail->CharSet = "utf-8"; // set charset to utf8
     	$mail->SMTPAuth = true;  // use smpt auth
     	$mail->SMTPSecure = "tls"; // or ssl
     	$mail->Host = "smtp.gmail.com";
     	$mail->Port = 587;// most likely something different for you. This is the mailtrap.io port i use for testing.
     	$mail->Username = "saturncubetest@gmail.com";
     	$mail->Password = "sc@testing#2019";
     	$mail->setFrom("saturncubetest@gmail.com", "FlightAdministration");
     	$mail->Subject = $subject;
     	$mail->MsgHTML($message);
     	$mail->addAddress($email,"FlightAdministration");
     	if($mail->send()) return 1;
 	} catch (phpmailerException $e) {
     	var_dump($e);
 	}		
}
function checkEmail($email){
	try
	{
		$moduleName="checkEmail";
		global $con;
		$arr['flag']=true;
		if(!empty($email))
		{
			$stmt1=$con->query("select * from user_mst where email='$email' and connect_to='1'");
			$count=$stmt1->num_rows;
			if($count>0)
			{
				$arr['flag']=false;
				$arr['msg']=EMAIL_EXISTS;
			}
			
		}
		return $arr;
	}
	catch(Exception $e)
	{
		send_error($e,$moduleName);
	}
}
function checkUserName($username){
	try
	{
		$moduleName="checkUserName";
		global $con;
		$arr['flag']=true;
		if(!empty($username))
		{
			$stmt1=$con->query("select * from user_mst where username='$username' and connect_to='1'");
			if($stmt1->num_rows>0)
			{
				$arr['flag']=false;
				$arr['msg']=USERNAME_EXISTS;
			}
		}
		return $arr;
	}
	catch(Exception $e)
	{
		send_error($e,$moduleName);
	}
}
function getLanguages(){
	try {
		$modualName="getLanguages";
		global $con;
		$array=array();
		$result=mysqli_query($con,"select * from language_mst")or throw_error(mysqli_error($con));
		while ($r=mysqli_fetch_assoc($result)) {
			array_push($array,$r);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getLabel($lang){
	try {
		$modualName="getLabel";
		global $con;
		$result=mysqli_query($con,"select lbl_index,`".$lang."`as lang from lbl_mst where active_flag=1")or throw_error(mysqli_error($con));
		while ($r=mysqli_fetch_assoc($result)) {
			$row[$r['lbl_index']]=$r['lang'];
		}
		return $row;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function register($username,$firstname,$lastname,$email,$password,$jobprofile){
	try {
		$moduleName="register";
		global $con;
		$array=array();
		$username_flag=checkUserName($username);
		$flag=checkEmail($email);
		if (!$flag['flag']) {
			$array['flag']=false;
			$array['msg']=$flag['msg'];
		}
		elseif (!$username_flag['flag']) {
			$array['flag']=false;
			$array['msg']=$username_flag['msg'];	
		}
		else{
			$active_flag='0';
			$crt_date=time();
			$password=md5($password);
			$code = generateRandomString();
			$code = md5($code);
			$store=$con->query("INSERT INTO user_mst (username,firstname,lastname,email,password,job_profile,connect_to,active_flag,active_code) values('$username','$firstname','$lastname','$email','$password','$jobprofile','1','$active_flag','$code')");
			$last_id=$con->insert_id;
			$result=$con->query("SELECT * FROM user_mst WHERE user_id = '$last_id'");
			$fetch_data=mysqli_fetch_assoc($result);
			$subject='Activate Account: FlightAdministration';
            $message ="Hello ".ucwords($fetch_data['firstname']).' '.ucwords($fetch_data['firstname']).",<br><br>";
			$message .="We have received your request to active account. If you have requested for the same then please <a href='".BASEPATH."api.php?action=activeAccount&email=".$fetch_data['email']."'>click here</a> to active.";
        	$sendmail=getSendMail($fetch_data['email'],$subject,$message);
    		$array['flag']=true;
			$array['msg']=REGISTER_SUCCESS;
		}
		return $array;
	}catch(Exception $e) {
		send_error($e,$moduleName);
	}
}
function activeAccount($email){
	try {
		$moduleName="activeAccount";
		global $con;
		$msg="";
		$array=array();
		$result=mysqli_query($con,"SELECT * FROM user_mst WHERE email='$email' AND active_flag='0' ") or die(mysqli_error($con));
		if($data=mysqli_fetch_assoc($result)){
			$user_id=$data['user_id'];
			mysqli_query($con,"UPDATE user_mst SET active_flag=1 WHERE user_id='$user_id'");
			echo "Activated Successfully";
		}
		else {
			$msg=ALREADY_ACTIVE;
		}
		return $msg;
	}catch(Exception $e) {
		send_error($e,$moduleName);
	}
}
function registerByOtherConnection($username,$connect_to,$password,$app_id,$firstname,$lastname){
	try {
		$moduleName="registerByOtherConnection";
		global $con;
		$array=array();
		$crt_date=time();
		$imagename='';
		$checkalreadyguest=$con->query("SELECT user_id,active_flag,firstname,lastname FROM user_mst WHERE email='$username' AND connect_to='$connect_to'");
		if($checkalreadyguest->num_rows>0){
			$guestdata=mysqli_fetch_assoc($checkalreadyguest);
			if($_FILES['profile_pic']['name']){
				$extension=pathinfo($_FILES['profile_pic']['name'],PATHINFO_EXTENSION);
				if($extension=="") $extension="jpg";
				$imagename=md5(time().rand(100,999)).".".$extension;
				move_uploaded_file($_FILES['profile_pic']['tmp_name'],"images/profile_pic/".$imagename);
			}
			$update=$con->query("UPDATE user_mst SET firstname='$firstname',lastname='$lastname',app_id='$app_id',crt_date='$crt_date' WHERE user_id='".$guestdata['user_id']."'");
			if($update){
				$array['flag']=true;
				$array['result']=$data;
			}
			else {
				$array['flag']=false;
			}
		}
		else{
			if($_FILES['profile_pic']['name']){
				$extension=pathinfo($_FILES['profile_pic']['name'],PATHINFO_EXTENSION);
				if($extension=="") $extension="jpg";
				$imagename=md5(time().rand(100,999)).".".$extension;
				move_uploaded_file($_FILES['profile_pic']['tmp_name'],"images/profile_pic/".$imagename);
			}
			$active_flag='1';
			$store=$con->query("INSERT into user_mst (firstname,lastname,email,profile_pic,connect_to,app_id,active_flag) values ('$firstname','$lastname','$username','$imagename','$connect_to','$app_id','$active_flag')");
			if($store) {
				$last_id=$con->insert_id;
				$result=$con->query("SELECT user_id,active_flag,firstname,lastname FROM user_mst WHERE user_id='$last_id'");
				$data=mysqli_fetch_assoc($checklogin);
				$array['flag']=true;
				$array['result']=$data;
			}
			else {
				$array['flag']=false;
			}
		}
		return $array;
	}catch(Exception $e) {
		send_error($e,$moduleName);
	}
}
function login($username,$connect_to,$password,$app_id,$firstname,$lastname){
	try {
		$moduleName="login";
		global $con;
		$array=array();
		if ($connect_to==1) {
			$password1=md5($password);
			$checklogin=$con->query("SELECT * FROM user_mst WHERE username='$username' AND password='$password1' AND active_flag=1");
			if($r=mysqli_fetch_assoc($checklogin)) {
				$array['flag']=true;
				$array['msg']=LOGIN_SUCCESS;
				$array['result']=$r;
			}
			else {
				$array['flag']=false;
				$array['msg']=LOGIN_ERROR;
			}
		}
		else{
			$data=registerByOtherConnection($username,$connect_to,$password,$app_id,$firstname,$lastname);
			if($data['flag']==true){
				$array['flag']=true;
				$array['msg']=LOGIN_SUCCESS;
				$array['result']=$data['result'];	
			}
		}
		return $array;
	}catch(Exception $e) {
		send_error($e,$moduleName);
	}
}
function getPlaneTypes(){
	try {
		$modualName="getPlaneTypes";
		global $con;
		$array=array();
		$result=$con->query("SELECT * FROM plane_type_mst WHERE active_flag='1'")or throw_error(mysqli_error($con));
		while ($data=mysqli_fetch_assoc($result)) {
			if($data['plane_type_icon']){
				$data['plane_type_icon']=BASEPATH."images/icons/".$data['plane_type_icon'];;
			}
			array_push($array, $data);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getManufacturereList($plane_type_id,$engine_type){
	try {
		$modualName="getManufacturereList";
		global $con;
		$array=array();
		$result=$con->query("select manfar.manufacturer_name as manufacturer_name, manfar.manufacturer_id as manufacturer_id, p.plane_type_id as plane_type_id,p.plane_type_name as plane_type_name,p.plane_icon as plane_icon, plan_manf.plane_type_id as plane_type_id from manufacturer_mst manfar inner join plane_manufacturer_mpg plan_manf ON plan_manf.manufacturer_id=manfar.manufacturer_id inner join plane_type_mst as p ON p.plane_type_id=plan_manf.plane_type_id where plan_manf.plane_type_id='$plane_type_id' and plan_manf.engine_type='$engine_type'")or throw_error(mysqli_error($con));
		while ($data=mysqli_fetch_assoc($result)) {
			$data['manufacturer_name'] = utf8_encode($data['manufacturer_name']);
			$data['plane_icon']=BASEPATH."images/icons/".$data['plane_icon'];
			array_push($array,$data);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getState(){
	try {
		$modualName="getState";
		global $con;
		$array=array();
		$result=$con->query("SELECT * FROM state_mst WHERE active_flag='1'")or throw_error(mysqli_error($con));
		while ($data=mysqli_fetch_assoc($result)) {
			$r['state_id']=$data['state_id'];
			$r['state_name']=$data['state_name'];
			array_push($array,$r);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getCityList($state_id){
	try {
		$modualName="getCityList";
		global $con;
		$array=array();
		$result=$con->query("select c.city_id as city_id,c.city_name as city_name,s.state_id as state_id from city_mst as c inner join state_mst as s ON s.state_id=c.state_id  where c.state_id='$state_id' and c.active_flag='1' ")or throw_error(mysqli_error($con));
		while ($data=mysqli_fetch_assoc($result)) {
			$r['city_id']=$data['city_id'];
			$r['city_name']=$data['city_name'];
			$r['state_id']=$data['state_id'];
			array_push($array,$r);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getAirportList($city_id){
	try {
		$modualName="getAirportList";
		global $con;
		$array=array();
		$result=$con->query("select a.airport_id as airport_id,a.airport_name as airport_name,a.loc_id as loc_id,c.city_id as city_id from airport_mst as a inner join city_mst as c ON a.city_id=c.city_id  where a.city_id='$city_id' and a.active_flag='1' ")or throw_error(mysqli_error($con));
		while ($data=mysqli_fetch_assoc($result)) {
			$r['airport_id']=$data['airport_id'];
			$r['airport_name']=$data['airport_name'];
			$r['city_id']=$data['city_id'];
			$r['loc_id']=$data['loc_id'];
			array_push($array,$r);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getFacilityList(){
	try {
		$modualName="getFacilityList";
		global $con;
		$array=array();
		$result=$con->query("SELECT * FROM facilities_mst ")or throw_error(mysqli_error($con));
		while($data=mysqli_fetch_assoc($result)) {
			$data['facility_icon']=BASEPATH.'images/icons/'.$data['facility_icon'];
			$data['facility_active_icon']=BASEPATH.'images/icons/'.$data['facility_active_icon'];
			array_push($array,$data);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getProfileDetails($user_id){
	try {
		$modualName="getProfileDetails";
		global $con;
		$array=array();
		$result=$con->query("SELECT email,about,profile_pic FROM user_mst WHERE user_id='$user_id'")or throw_error(mysqli_error($con));
		$r=mysqli_fetch_assoc($result);
		if(!empty($r['profile_pic'])){
			$r['profile_pic']=BASEPATH.'images/profile_pic/'.$r['profile_pic'];
		}else{
			$r['profile_pic'] = "";
		}
		if(empty($r['about'])){
			$r['about'] = "";
		}
		return $r;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getUserPlanes($user_id){
	try {
		$modualName="getUserPlanes";
		global $con;
		$array=array();
		$result=$con->query("select u.user_id as user_id,up.up_id as up_id,md.model_id as model_id,md.model_name as model_name,pl.plane_type_id as plane_type_id,pl.plane_type_name as plane_type_name,pl.plane_icon as plane_icon,manu.manufacturer_id as manufacturer_id,manu.manufacturer_name as manufacturer_name from user_mst as u inner join user_plane_mpg as up ON u.user_id=up.user_id inner join model_mst as md ON md.model_id=up.model_id inner join manufacturer_mst as manu ON md.manufacturer_id=manu.manufacturer_id inner join plane_type_mst as pl ON md.plane_type_id=pl.plane_type_id where up.user_id='$user_id'")or throw_error(mysqli_error($con));
		while($data=mysqli_fetch_assoc($result)) {
			$data['model_name'] = utf8_encode($data['model_name']);
			$data['plane_type_name'] = utf8_encode($data['plane_type_name']);	
			$data['manufacturer_name'] = utf8_encode($data['manufacturer_name']);
			$data["plane_icon"]=BASEPATH.'images/icons/'.$data["plane_icon"];
			array_push($array,$data);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function addPlaneOfUser($user_id,$model_id){
	try {
		$modualName="addPlaneOfUser";
		global $con;
		$msg="";
		$time=time();
		$check_user=$con->query("SELECT * FROM user_plane_mpg WHERE user_id='$user_id'");
		if($check_user->num_rows==0){
			$current=1;
		}
		else{
			$current=0;
		}
		$result=$con->query("INSERT INTO user_plane_mpg(model_id,user_id,current_plane,crt_date) values('$model_id','$user_id','$current','$time') ")or 	throw_error(mysqli_error($con));
		$msg=PLANE_ADD_SUCCESS;
		return $msg;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function addAirportOfUser($user_id,$airport_id){
	try {
		$modualName="addAirportOfUser";
		global $con;
		$msg="";
		$time=time();
		$check_user=$con->query("SELECT * FROM user_airport_mpg WHERE user_id='$user_id'");
		if($check_user->num_rows==0){
			$current=1;
		}
		else{
			$current=0;
		}
		$result=$con->query("INSERT INTO user_airport_mpg(airport_id,user_id,current_airport,crt_date) values('$airport_id','$user_id','$current','$time') ")or throw_error(mysqli_error($con));
		$msg=AIRPORT_ADD_SUCCESS;
		return $msg;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getUserAirports($user_id){
	try {
		$modualName="getUserAirports";
		global $con;
		$array=array();
		$result=$con->query("select ua.ua_id as ua_id,ua.current_airport as current_airport,ua.user_id as user_id,a.airport_id as airport_id,a.airport_name as airport_name,a.loc_id as loc_id,c.city_id as city_id,c.city_name as city_name,s.state_id as state_id,s.state_name as state_name from user_airport_mpg as ua left join user_mst as u ON ua.user_id = u.user_id left join airport_mst as a ON a.airport_id=ua.airport_id left join city_mst as c ON a.city_id=c.city_id left join state_mst as s ON c.state_id=s.state_id where ua.user_id='$user_id' and ua.active_flag=1 ")or throw_error(mysqli_error($con));
		while($data=mysqli_fetch_assoc($result)) {
			array_push($array,$data);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function changePassword($user_id,$oldpassword,$newpassword){
	try {
		$modualName="changePassword";
		global $con;
		$array=array();
		$oldpassword=md5($oldpassword);
		$newpassword=md5($newpassword);
		$result=$con->query("SELECT password FROM user_mst WHERE user_id ='$user_id'")or throw_error(mysqli_error($con));
		$dboldpas=mysqli_fetch_assoc($result);
		if($dboldpas['password']==$oldpassword){
			$updt=$con->query("UPDATE user_mst SET password='$newpassword' WHERE user_id='$user_id'");
			$array['flag']=1;
			$array['msg']=PASSWORD_CHAGE_SUCCESS;
		}
		else{
			$array['flag']=0;
			$array['msg']=OLD_PASSWORD_FAIL;
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function updateUserNames($user_id,$firstname,$lastname){
	try {
		$modualName="updateUserNames";
		global $con;
		$array=array();
		$updt=$con->query("UPDATE user_mst SET firstname='$firstname',lastname='$lastname' WHERE user_id='$user_id'");
		$array['flag']=1;
		$array['msg']=USER_NAME_CHANGE_SUCCESS;
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function updateUserAbout($user_id,$about){
	try {
		$modualName="updateUserAbout";
		global $con;
		$array=array();
		$updt=$con->query("UPDATE user_mst SET about='$about' WHERE user_id='$user_id'");
		$array['flag']=1;
		$array['msg']=USER_ABOUT_CHANGE_SUCCESS;
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function removeUserPlane($up_id){
	try {
		$modualName="removeUserPlane";
		global $con;
		$array=array();
		$delete=$con->query("DELETE FROM user_plane_mpg WHERE up_id='$up_id'");
		$array['flag']=1;
		$array['msg']=USER_PLANE_REMOVE_SUCCESS;
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function removeUserAirport($ua_id){
	try {
		$modualName="removeUserAirport";
		global $con;
		$array=array();
		$delete=$con->query("DELETE FROM user_airport_mpg WHERE ua_id='$ua_id'");
		$array['flag']=1;
		$array['msg']=USER_AIRPORT_REMOVE_SUCCESS;
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function updateCurrentPlane($user_id,$up_id){
	try {
		$modualName="updateCurrentPlane";
		global $con;
		$array=array();
		$update1=$con->query("UPDATE user_plane_mpg SET current_plane='0' WHERE user_id='$user_id'");
		$update2=$con->query("UPDATE user_plane_mpg SET current_plane='1' WHERE user_id='$user_id' AND up_id='$up_id'");
		$array['flag']=1;
		$array['msg']=USER_PLANE_UPDT_SUCCESS;
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function updateCurrentAirport($user_id,$ua_id){
	try {
		$modualName="updateCurrentAirport";
		global $con;
		$array=array();
		$update1=$con->query("UPDATE user_airport_mpg SET current_airport='0' WHERE user_id='$user_id'");
		$update2=$con->query("UPDATE user_airport_mpg SET current_airport='1' WHERE user_id='$user_id' AND ua_id='$ua_id'");
		$array['flag']=1;
		$array['msg']=USER_AIRPORT_UPDT_SUCCESS;
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function updateProfilePic($user_id){
	try {
		$modualName="updateProfilePic";
		global $con;
		$array=array();
		$user_data=$con->query("SELECT * FROM user_mst WHERE user_id='$user_id'");
		$data=mysqli_fetch_assoc($user_data);
		$imagename='';
		if(!empty($_FILES['profile_pic']['name']))
		{
			if(!empty($data['profile_pic'])){
				unlink(BASEPATH.'images/profile_pic/'.$data['profile_pic']);
			}
			$extension=pathinfo($_FILES['profile_pic']['name'],PATHINFO_EXTENSION);
			if($extension=="") $extension="jpg";
			$imagename=md5(time().rand(100,999)).".".$extension;
			move_uploaded_file($_FILES['profile_pic']['tmp_name'],"images/profile_pic/".$imagename);
		}
		$updt=$con->query("UPDATE user_mst SET profile_pic='$imagename' WHERE user_id = '$user_id'");
		$array['flag']=1;
		$array['msg']=USER_PROFILE_PIC_UPDT;
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function mechanicfacility($mechanic_id){
	try {
		$modualName="mechanicfacility";
		global $con;
		$array=array();
		$result=$con->query("select f.facility_name as facility_name,f.facility_active_icon as facility_active_icon from mechanic_facility_mpg as m inner join facilities_mst as f ON m.facility_id=f.facility_id where m.mechanic_id ='$mechanic_id'")or throw_error(mysqli_error($con));
		while($data=mysqli_fetch_assoc($result)) {
			$data['facility_active_icon']=BASEPATH.'images/icons/'.$data['facility_active_icon'];
			array_push($array,$data);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getmechanicrating($mechanic_id){
	try {
		$modualName="getmechanicrating";
		global $con;
		$result=$con->query("SELECT AVG(rating) as avgRate FROM mechanic_review_mst WHERE mechanic_id='$mechanic_id' ")or throw_error(mysqli_error($con));
		$r=mysqli_fetch_assoc($result);
		if(empty($r['avgRate'])){
			$r['avgRate'] = 0.00;
		}
		return $r['avgRate'];
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getMechanicList($airport_id,$user_id,$latitude,$longitude,$search,$facilities){
	try {
		$modualName="getMechanicList";
		global $con;
		$array=array();
		$query="select m.mechanic_id as mechanic_id ,m.mechanic_name as mechanic_name,m.mobile_no as mobile_no,m.profile_pic as profile_pic,m.street_address as street_address,m.zipcode as zipcode,m.from_hours,m.to_hours,m.hourly_rate,m.after_hour_rate,m.certificate,m.easa,m.other_certificate,m.website,m.aog,m.manuals,m.ffa_certi,m.program, c.city_id as city_id,c.city_name as city_name,s.state_id as state_id,s.state_name as state_name,a.latitude as latitude,a.longitude as longitude,a.airport_name from mechanic_mst as m left join mechanic_airport_mpg as ma ON ma.mechanic_id=m.mechanic_id left join airport_mst as a ON ma.airport_id=a.airport_id left join city_mst as c ON a.city_id=c.city_id left join state_mst as s ON c.state_id=s.state_id where m.mechanic_name like '%$search%' AND ma.airport_id='".$airport_id."' ";
		$result=$con->query($query);
		while($data=mysqli_fetch_assoc($result)) {
			$data['airport_name'] = utf8_encode($data['airport_name']);
			if(!empty($data['profile_pic'])){
				$data['profile_pic']=BASEPATH.'images/profile_pic/'.$data['profile_pic'];
			}else{
				$data['profile_pic'] = "";
			}
			if(empty($data['street_address'])){
				$data['street_address'] = "";
			}
			if(empty($data['zipcode'])){
				$data['zipcode'] = "";
			}
			if(empty($data['mobile_no'])){
				$data['mobile_no'] = "";
			}
			if(empty($data['hourly_rate'])){
				$data['hourly_rate'] = "0";
			}
			if(empty($data['after_hour_rate'])){
				$data['after_hour_rate'] = "0";
			}
			if(empty($data['certificate'])){
				$data['certificate'] = "";
			}
			if(empty($data['easa'])){
				$data['easa'] = "0";
			}
			if(empty($data['other_certificate'])){
				$data['other_certificate'] = "";
			}
			if(empty($data['manuals'])){
				$data['manuals'] = "0";
			}
			if(empty($data['website'])){
				$data['website'] = "0";
			}
			$data['facilities'] = mechanicfacility($data['mechanic_id']);
			$data['avgRating'] = getmechanicrating($data['mechanic_id']);
			array_push($array,$data);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function addRating($user_id,$rating,$mechanic_id,$comment){
	try {
		$modualName="addRating";
		global $con;
		$array=array();
		$time=time();
		$store=$con->query("INSERT INTO mechanic_review_mst(rating,user_id,mechanic_id,comment,crt_date) values('$rating','$user_id','$mechanic_id','$comment','$time') ")or throw_error(mysqli_error($con));
		$array['flag']=1;
		$array['msg']=RATING_ADD_SUCCESS;
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function viewRating($mechanic_id){
	try {
		$modualName="viewRating";
		global $con;
		$array=array();
		$result=$con->query("select r.review_id as review_id,r.rating as rating,r.comment as comment,u.user_id as user_id,u.firstname as firstname,u.lastname as lastname from mechanic_review_mst as r inner join user_mst as u ON u.user_id = r.user_id where r.mechanic_id='$mechanic_id'")or throw_error(mysqli_error($con));

		while($data=mysqli_fetch_assoc($result)) {
			array_push($array, $data);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function deleteRating($review_id){
	try {
		$modualName="deleteRating";
		global $con;
		$array=array();
		$delete=$con->query("DELETE FROM mechanic_review_mst WHERE review_id='$review_id'")or throw_error(mysqli_error($con));
		$array['flag']=1;
		$array['msg']='Successfully';
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getModelList($plane_type_id,$manufacturer_id,$engine_type){
	try {
		$modualName="getModelList";
		global $con;
		$array=array();
		$result=mysqli_query($con,"SELECT model_id,model_name FROM model_mst WHERE plane_type_id='$plane_type_id' AND manufacturer_id='$manufacturer_id' AND engine_type='$engine_type'")or throw_error(mysqli_error($con));
		while ($data=mysqli_fetch_assoc($result)) {
			array_push($array, $data);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function forgetPassword($email){
	try {
		$modualName="forgetPassword";
		global $con;
		$array=array();
		$result=mysqli_query($con,"SELECT * FROM user_mst WHERE email='$email'") or die(mysqli_error($con));
		if($data=mysqli_fetch_assoc($result)){
			$email=$data['email'];
			if($data['connect_to']==1){
				$code=$data['active_code'];
			}
			else{
				$code=$data['app_id'];	
			}
			$subject='FlightAdministration : Password Reset';
            $message ="Hello ".ucwords($data['firstname']).' '.ucwords($data['firstname']).",<br><br>";
			$message .="We have received your request to reset password. If you have requested for the same then please <a href='".BASEPATH."api.php?action=confirmForgetPassword&email=".$email."&code=".$code."'>click here</a> to confirm.";
        	$sendmail=getSendMail($data['email'],$subject,$message);
        	if($sendmail==1){
        		$array['flag']=1;
				$array['msg']=PASSWORD_MAIL_SEND_SUCCESS;
        	}
        	else{
        		$array['flag']=0;
				$array['msg']='Fail to send';
        	}
		}
		else{
			$array['flag']=0;
			$array['msg']=INVALID_EMAIL;
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function confirmChangeForgetPassword($email,$code) {
	try {
		$moduleName="confirmChangeForgetPassword";
		global $con;

		$msg="";
		$result=mysqli_query($con,"SELECT * FROM user_mst WHERE email='$email' AND active_code=$code ") or die(mysqli_error($con));
		if($data=mysqli_fetch_assoc($result)){
			$user_id=$data['user_id'];
			$password=generateRandomString(); 
			$passwordMD5=md5($password);
			$subject="Changed Password :FlightAdministration";
			mysqli_query($con,"UPDATE user_mst password='$passwordMD5' WHERE user_id='$user_id'") or die(mysqli_error($con));
			$message ="Hello ".ucwords($name).",<br><br>";
			$message .="Please use the following password to login FlightAdministration : ".$password;
			$message .="<br><br>We recommend you to change your password once you are logged in.";
			if(getSendMail($email,$subject,$message)) {
				$msg=FORGET_PASS;
			}
			else {
				$msg=MAIL_NOT_SENT;
			}
		}
		else {
			$msg=EMAIL_NOT_REGISTERED;
		}
		return $msg;
	} catch (Exception $e) {
		send_error($e,$moduleName);
	}
}
function getAvgRating($mechanic_id){
	try {
		$modualName="getAvgRating";
		global $con;
		$array=array();
		$avg=$con->query("SELECT AVG(rating) as avgRate FROM mechanic_review_mst WHERE mechanic_id='$mechanic_id'");
		$r=mysqli_fetch_assoc($avg);
		if(empty($r['avgRate'])){
			$r['avgRate'] = 0;
		}
		return $r['avgRate'];
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getNearByAirports($latitude,$longitude){
	try {
		$modualName="getNearByAirports";
		global $con;
		$array=array();
		$result=$con->query("SELECT airport_mst.*,( 3959 * acos(cos(radians('$latitude'))*cos(radians(latitude))*cos(radians(longitude)-radians('$longitude'))+sin(radians('$latitude'))*sin(radians(latitude)))) AS distance from airport_mst HAVING distance <= 25 ORDER BY distance ASC");
		while($data=mysqli_fetch_assoc($result)) {
			$r['airport_id']=$data['airport_id'];
			$r['airport_name']=$data['airport_name'];
			$r['loc_id']=$data['loc_id'];
			$r['latitude']=$data['latitude'];
			$r['longitude']=$data['longitude'];
			$r['distance']=$data['distance'];
			array_push($array,$r);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function searchAirports($keyword){
	try {
		$modualName="searchAirports";
		global $con;
		$array=array();
		$result=$con->query("select a.loc_id as loc_id ,a.airport_name as airport_name,a.airport_id as airport_id,a.latitude as latitude,a.longitude as longitude,c.city_id as city_id,c.city_name as city_name,s.state_id as state_id,s.state_name as state_name from airport_mst as a inner join city_mst c ON a.city_id=c.city_id inner join state_mst as s ON c.state_id=s.state_id where a.airport_name like '%$keyword%' OR loc_id='".$keyword."' GROUP BY loc_id ");
		while($data=mysqli_fetch_assoc($result)) {
			$data['airport_name'] = utf8_encode($data['airport_name']);
			if(empty($data['latitude'])){
				$data['latitude'] = '';
			}
			if(empty($data['longitude'])){
				$data['longitude'] = '';
			}
			array_push($array,$data);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getJobProfiles(){
	try {
		$modualName="getJobProfiles";
		global $con;
		$array=array();
		
		$result=$con->query("SELECT * FROM job_profile_mst WHERE active_flag = '1'")or throw_error(mysqli_error($con));
		while($data=mysqli_fetch_assoc($result)) {
			$r['job_profile_id']=$data['job_profile_id'];
			$r['job_name']=$data['job_name'];
			array_push($array,$r);
		}
		return $array;
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}
function getCurrentPlane($user_id){
	try {
		$modualName="getCurrentPlane";
		global $con;
		$array=array();
		$result=mysqli_query($con,"select up.up_id as up_id,md.model_id as model_id,md.model_name as model_name,manu.manufacturer_id as manufacturer_id,manu.manufacturer_name as manufacturer_name,p.plane_type_id as plane_type_id,p.plane_type_name as plane_type_name,p.plane_icon as plane_icon from user_plane_mpg as up left join model_mst as md ON up.model_id=md.model_id left join manufacturer_mst as manu ON md.manufacturer_id = manu.manufacturer_id left join plane_type_mst as p ON md.plane_type_id=p.plane_type_id where up.user_id='$user_id' and up.current_plane=1") or throw_error(mysqli_error($con));
		if($data=mysqli_fetch_assoc($result)){
			$data['plane_icon']=BASEPATH.'images/icons/'.$data['plane_icon'];
			return $data;
		}else{
			return $array;
		}
	} catch (Exception $e) {
		send_error($e,$modualName);
	}
}